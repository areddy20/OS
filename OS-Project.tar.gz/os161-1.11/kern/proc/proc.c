#include <proc.h>
#include <lib.h>
#include <kern/errno.h>

struct proc* proc_table[MAX_PROCESSES];
struct lock* proc_table_lock;
int last_pid_location;


void proc_init() {
    
    int i;
    for (i = 0; i < MAX_PROCESSES; i++) {
        proc_table[i] = NULL;
    }

    proc_table_lock = lock_create("process_table_lock");
    if (!proc_table_lock) {
        panic("proc_init::Cannot create proc_table_lock");
    }

    last_pid_location = 0;
}

int proc_create(struct proc **ret) {
    struct proc *tmp;
    int error = 0;
    int i;
    int found_free_pid = -1;

    lock_acquire(proc_table_lock);

    if (last_pid_location >= MAX_PROCESSES) {
        last_pid_location = 0;
    }
    for (i = last_pid_location; i < MAX_PROCESSES; i++) {
        if (!proc_table[i]) {
            found_free_pid = i;
            break;
        }
    }
    for (i = 0; i < MAX_PROCESSES && found_free_pid == -1; i++) {
        if (!proc_table[i]) {
            found_free_pid = i;
            break;
        }
    }

    if (found_free_pid == -1) {
        error = EAGAIN;
    }
    else {
        tmp = kmalloc( sizeof( struct proc ) );
        if(tmp == NULL ) {
            error = ENOMEM;
        }
        else if (!(tmp->plock = lock_create("Process Lock"))) {
            kfree(tmp);
            error = ENOMEM;
        }
        else if (!(tmp->sem = sem_create("proc sem", 0))) {
            kfree(tmp);
            lock_destroy(tmp->plock);
            error = ENOMEM; 
        }
        else {
            tmp->pid = found_free_pid;
            tmp->parent = NULL;
            tmp->return_code = 0;
            tmp->done = 0;
            *ret = tmp;
            proc_table[found_free_pid] = tmp;
            last_pid_location = found_free_pid;
        }
    }
    lock_release(proc_table_lock);
    return error;
}



