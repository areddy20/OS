#include <types.h>
#include <lib.h>

void
hello(void)
{
    kprintf("Hello World!\n");
}
