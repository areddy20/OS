#ifndef __PROC_H__
#define __PROC_H__

#include <types.h>
#include <synch.h>

#define MAX_PROCESSES 32

struct proc {
    pid_t pid;
    struct lock *plock;    
    struct proc *parent;
    int return_code;  
    int done;
    struct semaphore *sem;
};

extern struct proc* proc_table[MAX_PROCESSES];
extern struct lock* proc_table_lock;

#define PROC_LOCK(x)        (lock_acquire((x)->plock))
#define PROC_UNLOCK(x)      (lock_release((x)->plock))
#define PROCTABLE_LOCK()    (lock_acquire(proc_table_lock))
#define PROCTABLE_UNLOCK()  (lock_release(proc_table_lock))



void    proc_init();
int	    proc_create(struct proc **ret);


#endif