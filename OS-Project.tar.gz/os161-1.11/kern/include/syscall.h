#ifndef _SYSCALL_H_
#define _SYSCALL_H_

#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <syscall.h>


/*
 * Prototypes for IN-KERNEL entry points for system call implementations.
 */

int sys_reboot(int code);

// PA 2

int sys_getpid(int *retval);
int sys_getppid(int *retval);

int sys_fork(struct trapframe* tf, pid_t *retval);
int sys_execv(const char* progname, char **args, pid_t *retval);
int sys_waitpid(pid_t pid, userptr_t user_retval, int flags, int *retval );
void sys_exit(int code);
  



#endif /* _SYSCALL_H_ */
