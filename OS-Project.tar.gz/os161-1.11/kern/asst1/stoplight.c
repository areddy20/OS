/*
 * stoplight.c
 *
 * 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
 *
 * NB: You can use any synchronization primitives available to solve
 * the stoplight problem in this file.
 */


/*
 *
 * Includes
 *
 */

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>


/*
 *
 * Constants
 *
 */

/*
 * Number of vehicles created.
 */

#define NVEHICLES 20 





/* Create locks to manage access to different parts of the intersection  */

struct lock *lockAB;
struct lock *lockBC;
struct lock *lockCA;

/* Create lock for the intersection  -  Ensures atomic updates to car and truck counts.*/

struct lock *intersectionLock;

/* Create locks for each lane  - To manage access to each lane approaching the intersection.*/

struct lock *lockLaneA;
struct lock *lockLaneB;
struct lock *lockLaneC;

/* Initialize  Counters for cars in each lane - To monitor the number of cars */

int carCountA = 0;
int carCountB = 0;
int carCountC = 0;

/* Initialize Counters for trucks in each lane - To monitor the number of trucks */

int truckCountA = 0;
int truckCountB = 0;
int truckCountC = 0;

/* Mutex for message printing  - Guarantees messages print without any interruption*/

struct lock *msgLock;




/*
 *
 * Function Definitions
 *
 */



/*
 * turnleft()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a left turn through the
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnleft(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	/*
	 * Avoid unused variable warnings.
	 */

	/* Find out correct lane lock based on vehicledirection value */

	struct lock *laneLock;

	switch(vehicledirection)

	{
	     case 0: laneLock = lockLaneA; break;
	     case 1: laneLock = lockLaneB; break;
	     case 2: laneLock = lockLaneC; break;
	     default: return;
    }


    /* Log the approach message */

    lock_acquire(msgLock);
    kprintf("%% %s %lu from Route %c to turn LEFT to Route %c APPROACHES the intersection\n", vehicletype ? "Truck" : "Car", vehiclenumber, 'A' + vehicledirection, 'A' + (vehicledirection + 2) % 3);
    lock_release(msgLock);


   /* Aquire locks */

   /* Acquire the lanelock */
   lock_acquire(laneLock);

   /* Acquire the intersection lock */
   lock_acquire(intersectionLock);

   /* Increment the car or truck count for the appropriate lane */

   if (vehicletype == 0)  // Car
    {
       switch(vehicledirection)
       {
               case 0: carCountA++; break;
               case 1: carCountB++; break;
               case 2: carCountC++; break;
       }
     }
     else //Truck
     {
          switch(vehicledirection) {
               case 0: truckCountA++; break;
               case 1: truckCountB++; break;
               case 2: truckCountC++; break;
      }

    }


    /* Now release the intersection lock */
	lock_release(intersectionLock);

   /* Check if it's OK for trucks to proceed */
    if (vehicletype == 1)

    {
	        while (1)
	        {
	            lock_acquire(intersectionLock);
	            if (carCountA + carCountB + carCountC == 0) {
	                lock_release(intersectionLock);
	                break;
	            }

	            lock_release(intersectionLock);
	            thread_yield(); // This will allow other vehicles to check conditions
	        }
    }

    /* Log enter message for the first part of the intersection */

	lock_acquire(msgLock);
	kprintf("%% %s %lu from Route %c to turn LEFT to Route %c ENTERED %c%c\n", vehicletype ? "Truck" : "Car", vehiclenumber, 'A' + vehicledirection, 'A' + (vehicledirection + 2) % 3, 'A' + vehicledirection, 'A' + (vehicledirection + 1) % 3);
	lock_release(msgLock);

    /* Now time to acquire the correct lock for the second part of the intersection */

	switch((vehicledirection + 1) % 3)
	 {
	        case 0: lock_acquire(lockBC); break;
	        case 1: lock_acquire(lockCA); break;
	        case 2: lock_acquire(lockAB); break;
	 }

   /* Now release the second lock */

   switch((vehicledirection + 1) % 3)
   {
	        case 0: lock_release(lockBC); break;
	        case 1: lock_release(lockCA); break;
	        case 2: lock_release(lockAB); break;
   }


  /* Now release the lane lock */
  lock_release(laneLock);



 /* Log leave message */

 lock_acquire(msgLock);
 kprintf("%% %s %lu from Route %c to turn LEFT to Route %c LEFT %c%c\n", vehicletype ? "Truck" : "Car", vehiclenumber, 'A' + vehicledirection, 'A' + (vehicledirection + 2) % 3, 'A' + (vehicledirection + 1) % 3, 'A' + (vehicledirection + 2) % 3);
 lock_release(msgLock);


/* Decrement the car or truck count for the appropriate lane */

lock_acquire(intersectionLock);

if (vehicletype == 0)  // Car
{
    switch(vehicledirection)
    {
        case 0: carCountA--; break;
        case 1: carCountB--; break;
        case 2: carCountC--; break;
    }
}
else  // Truck
{
    switch(vehicledirection)
    {
        case 0: truckCountA--; break;
        case 1: truckCountB--; break;
        case 2: truckCountC--; break;
    }
}

lock_release(intersectionLock);

}


/*
 * turnright()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a right turn through the
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnright(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	/*
	 * Avoid unused variable warnings.
	 */


	/* Find out the appropriate lane lock based on vehicledirection value*/
	 struct lock *laneLock;

	 switch(vehicledirection) {
	        case 0: laneLock = lockLaneA; break;
	        case 1: laneLock = lockLaneB; break;
	        case 2: laneLock = lockLaneC; break;
	        default: return;
    }


     /* Log the approach message */

	 lock_acquire(msgLock);
	 kprintf("%% %s %lu from Route %c to turn RIGHT to Route %c APPROACHES the intersection\n", vehicletype ? "Truck" : "Car", vehiclenumber, 'A' + vehicledirection, 'A' + (vehicledirection + 1) % 3);
     lock_release(msgLock);



	/* Aquire locks */

	/* Acquire the lane lock */
    lock_acquire(laneLock);

    /* Acquire the intersection lock */
    lock_acquire(intersectionLock);


    /* Increment the car or truck count for the appropriate lane */
	if (vehicletype == 0)  // Car
	 {
	     switch(vehicledirection)
	     {
	            case 0: carCountA++; break;
	            case 1: carCountB++; break;
	            case 2: carCountC++; break;
	       }
	 }
	 else // Truck
	  {
	        switch(vehicledirection) {
	            case 0: truckCountA++; break;
	            case 1: truckCountB++; break;
	            case 2: truckCountC++; break;
	   }
    }


    /* Now Release the intersection lock */
    lock_release(intersectionLock);

	/* Check if it's OK for trucks to proceed */
	if (vehicletype == 1)
	{
	        while (1) {
	            lock_acquire(intersectionLock);
	            if (carCountA + carCountB + carCountC == 0) {
	                lock_release(intersectionLock);
	                break;
	            }
	            lock_release(intersectionLock);
	            thread_yield(); // This will allow other vehicles to verify conditions
	        }
    }

    /* Now acquire the appropriate lock for the right side of the intersection */

	   switch(vehicledirection) {
	        case 0: lock_acquire(lockAB); break;
	        case 1: lock_acquire(lockBC); break;
	        case 2: lock_acquire(lockCA); break;
	    }

	    /* Now Release the lock */
	    switch(vehicledirection) {
	        case 0: lock_release(lockAB); break;
	        case 1: lock_release(lockBC); break;
	        case 2: lock_release(lockCA); break;
	    }

	 /* Release the lane lock */
	 lock_release(laneLock);

    /* Log  leave message */
	 lock_acquire(msgLock);
	 kprintf("%% %s %lu from Route %c to turn RIGHT to Route %c LEFT %c%c\n", vehicletype ? "Truck" : "Car", vehiclenumber, 'A' + vehicledirection, 'A' + (vehicledirection + 1) % 3, 'A' + vehicledirection, 'A' + (vehicledirection + 1) % 3);
	 lock_release(msgLock);

    /* Decrement the car or truck count for the appropriate lane */
	lock_acquire(intersectionLock);

	if (vehicletype == 0) // Car
	{
		    switch(vehicledirection) {
		        case 0: carCountA--; break;
		        case 1: carCountB--; break;
		        case 2: carCountC--; break;
		    }
		}
	else // Truck
	{
		    switch(vehicledirection) {
		        case 0: truckCountA--; break;
		        case 1: truckCountB--; break;
		        case 2: truckCountC--; break;
		    }
		}

   lock_release(intersectionLock);



}


/*
 * approachintersection()
 *
 * Arguments:
 *      void * unusedpointer: currently unused.
 *      unsigned long vehiclenumber: holds vehicle id number.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      Change this function as necessary to implement your solution. These
 *      threads are created by createvehicles().  Each one must choose a direction
 *      randomly, approach the intersection, choose a turn randomly, and then
 *      complete that turn.  The code to choose a direction randomly is
 *      provided, the rest is left to you to implement.  Making a turn
 *      or going straight should be done by calling one of the functions
 *      above.
 */

static
void
approachintersection(void * unusedpointer,
		unsigned long vehiclenumber)
{
	int vehicledirection, turndirection, vehicletype;

	/*
	 * Avoid unused variable and function warnings.
	 */



	/*
	 * vehicledirection is set randomly.
	 */

	vehicledirection = random() % 3;
	turndirection = random() % 2;
	vehicletype = random() % 2;

	/* Calculate the correct turn direction based on vehicledirection */
	if (vehicledirection == 0) {
	    turndirection = random() % 2; // 0 for left, 1 for right
	    } else if (vehicledirection == 1) {
	        turndirection = random() % 2; // 0 for left, 1 for right
	    } else {
	        turndirection = 0;
	    }

  /* Depending on the turn direction, call the appropriate function */
  if (turndirection == 0) {
	        turnleft(vehicledirection, vehiclenumber, vehicletype);
	    } else {
	         turnright(vehicledirection, vehiclenumber, vehicletype);
    }



}


/*
 * createvehicles()
 *
 * Arguments:
 *      int nargs: unused.
 *      char ** args: unused.
 *
 * Returns:
 *      0 on success.
 *
 * Notes:
 *      Driver code to start up the approachintersection() threads.  You are
 *      free to modiy this code as necessary for your solution.
 */

int
createvehicles(int nargs,
		char ** args)
{
	int index, error;

	/*
	 * Avoid unused variable warnings.
	 */

	/* Initialize the locks */
	lockAB = lock_create("lockAB");
	lockBC = lock_create("lockBC");
	lockCA = lock_create("lockCA");

	intersectionLock = lock_create("intersectionLock");
	msgLock = lock_create("msgLock");

	/* Initialize the lane locks */
	lockLaneA = lock_create("lockLaneA");
	lockLaneB = lock_create("lockLaneB");
    lockLaneC = lock_create("lockLaneC");

	/*
	 * Start NVEHICLES approachintersection() threads.
	 */

	for (index = 0; index < NVEHICLES; index++) {

		error = thread_fork("approachintersection thread",
				NULL,
				index,
				approachintersection,
				NULL
				);

		/*
		 * panic() on error.
		 */

		if (error) {

			panic("approachintersection: thread_fork failed: %s\n",
					strerror(error)
				 );
		}
	}

	return 0;
}

