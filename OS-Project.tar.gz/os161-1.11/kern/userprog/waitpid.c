#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <syscall.h>
#include <proc.h>
#include <curthread.h>
#include <thread.h>

int sys_waitpid(pid_t pid, userptr_t user_returnval, int flags, int *retval)
{
    struct proc *p = NULL;
    int i;
    int process_returncode = 0;
    int err = 0;

    if (flags != 0 || pid < 0 || pid >= MAX_PROCESSES) {
        return EINVAL;
    }
    
    // this will find the process with id
    PROCTABLE_LOCK();

    for (i = 0; i < MAX_PROCESSES; i++) {
        if (proc_table[i] && proc_table[i]->pid == pid) {
            p = proc_table[i];
            break;
        }
    }
    PROCTABLE_UNLOCK();

    if (!p) {
        return EINVAL;
    }

    PROC_LOCK(p);
    if (p->done == 0) {
        PROC_UNLOCK(p);
        P(p->sem);
        PROC_LOCK(p);
    }    
    p->done = 1;
    process_returncode = p->return_code;
    *retval = pid;
    if (user_returnval) {
        process_returncode << 2;
	    err = copyout(&process_returncode, user_returnval, sizeof(int));
    }
    PROC_UNLOCK(p);

    // This will remove process
    PROCTABLE_LOCK();
    lock_destroy(p->plock);
    sem_destroy(p->sem);
    kfree(p);
    proc_table[i] = NULL;
    PROCTABLE_UNLOCK();
    
    return err;
}


