#include <types.h>
#include <kern/unistd.h>
#include <kern/errno.h>
#include <lib.h>
#include <addrspace.h>
#include <thread.h>
#include <curthread.h>
#include <vm.h>
#include <vfs.h>
#include <test.h>


void 
copy_string_from_userland(char* usersrc, char *dst, int *len)
{
    int res;

    *len = 0;

    while (1) {
        char ch = 0;
        res = copyin(usersrc, &ch, sizeof(char));
        if (res) {
            return EFAULT;
        }
        *dst = ch;
        *len = (*len) + 1;
        dst++;
        usersrc++;
        if (!ch) {
            break;
        }
    }
}

int
sys_execv(const char* progname, char* userargs[], pid_t *retval)
{

    
    // step 1) Copy user arguments from userland to kernel space.

    //step 2) Perform the same actions as runprogram to execute the program.

    //step 3) Copy the arguments back from kernel space to the user stack.

    //step 4) Execute the program using the copied arguments on the user stack. 
    
    int i;
    int argc;

    char *args[50];
    char kstring[100];

    // Step 1
    i = 0;
    while (1) {
        int len;

        // Check if userargs[i] is NULL
        char *arg_ptr = NULL;
        int res;
        res = copyin(userargs + i, &arg_ptr, sizeof(char*));
        if (res) {
            return EFAULT;
        }
        if (!arg_ptr) {
            args[i] = NULL;
            break;
        }

        len = 0;
        copy_string_from_userland(arg_ptr, kstring, &len);
        args[i] = kstrdup(kstring);
        i++;
    }


	struct vnode *v;
	vaddr_t entrypoint, stackptr;
	int result;

	result = vfs_open(progname, O_RDONLY, &v);

	if (result) {
		return result;
	}

    if (curthread->t_vmspace != NULL) {
        as_destroy(curthread->t_vmspace);
    }

	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace==NULL) {
		vfs_close(v);
		return ENOMEM;
	}

	as_activate(curthread->t_vmspace);

	result = load_elf(v, &entrypoint);
	if (result) {
		vfs_close(v);
		return result;
	}

	vfs_close(v);

	result = as_define_stack(curthread->t_vmspace, &stackptr);
	if (result) {
		return result;
	}


    argc = 0;
    i = 0;
    while (args[i] != NULL) {
        argc++;
        i++;
    }

	// Step 3
	for (i = 0; i < argc; i++) {
		int len;
		int res;
		int j;

		len = strlen(args[i]);
		len = (len + 7) / 8 * 8;

		stackptr -= len;
		for (j = 0; j < len; ++j) {
			char null = '\0';
			res = copyout((const void *)(&null),(userptr_t)(stackptr+j), sizeof(char));
			if (res) {
				return EFAULT;
			}
		}
		res=copyout((const void *)args[i],(userptr_t)stackptr, len);
		if (res) {
			return EFAULT;
		}
		args[i] = (char*) stackptr;
	}
	

	for (i = argc; i >= 0; i--) {
		int res;
		char *ptr = (i==argc)?NULL: args[i];
		stackptr -= sizeof(char*);
		res = copyout((const void *)&ptr,(userptr_t)stackptr, sizeof(char*));
		if (res) {
			return EFAULT;
		}
	}

	// step 4
	md_usermode(argc,
				(userptr_t)stackptr,
				stackptr, 
				entrypoint);
	
	panic("md_usermode returned\n");
	return EINVAL;
}
