/*
 * Sample/test code for running a user program.  You can use this for
 * reference when implementing the execv() system call. Remember though
 * that execv() needs to do more than this function does.
 */

#include <types.h>
#include <kern/unistd.h>
#include <kern/errno.h>
#include <lib.h>
#include <addrspace.h>
#include <thread.h>
#include <curthread.h>
#include <vm.h>
#include <vfs.h>
#include <test.h>

/*
 * Load program "progname" and start running it in usermode.
 * Does not return except on error.
 *
 * Calls vfs_open on progname and thus may destroy it.
 */
int
runprogram(char *progname, int argc, char **argv)
{
	int i;

	struct vnode *v;
	vaddr_t entrypoint, stackptr;
	int result;

	result = vfs_open(progname, O_RDONLY, &v);

	if (result) {
		return result;
	}

	assert(curthread->t_vmspace == NULL);

	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace==NULL) {
		vfs_close(v);
		return ENOMEM;
	}

	as_activate(curthread->t_vmspace);

	result = load_elf(v, &entrypoint);
	if (result) {
		vfs_close(v);
		return result;
	}

	vfs_close(v);

	result = as_define_stack(curthread->t_vmspace, &stackptr);
	if (result) {
		return result;
	}

	for (i = 0; i < argc; i++) {
		int len;
		int res;
		int j;

		len = strlen(argv[i]);
		len = (len + 7) / 8 * 8;

		stackptr -= len;
		for (j = 0; j < len; ++j) {
			char null = '\0';
			res = copyout((const void *)(&null),(userptr_t)(stackptr+j), sizeof(char));
			if (res) {
				return EFAULT;
			}
		}
		res=copyout((const void *)argv[i],(userptr_t)stackptr, len);
		if (res) {
			return EFAULT;
		}
		argv[i] = (char*) stackptr;
	}
	

	for (i = argc; i >= 0; i--) {
		int res;
		char *ptr = (i==argc)?NULL: argv[i];
		stackptr -= sizeof(char*);
		res = copyout((const void *)&ptr,(userptr_t)stackptr, sizeof(char*));
		if (res) {
			return EFAULT;
		}
	}

	md_usermode(argc,
				(userptr_t)stackptr,
				stackptr, 
				entrypoint);
	
	panic("md_usermode returned\n");
	return EINVAL;
}

