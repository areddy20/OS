#include <syscall.h>
#include <lib.h>
#include <proc.h>
#include <thread.h>
#include <curthread.h>

void sys_exit(int code) {
    struct proc *p = NULL;
    
    assert( curthread != NULL );
	assert( curthread->t_proc != NULL );
	
	p = curthread->t_proc;

    PROC_LOCK(p);
    p->done = 1;
    p->return_code = code;
    PROC_UNLOCK(p);
    V(p->sem);

    thread_exit();
}


