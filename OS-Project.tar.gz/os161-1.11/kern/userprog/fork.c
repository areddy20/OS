#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <syscall.h>
#include <proc.h>
#include <curthread.h>
#include <thread.h>

struct fork_thread_arguments {
    struct proc      *child_proc;
    struct addrspace *child_vmspace;
    struct trapframe *child_trapframe;
};

void fork_child_entry(void *args, void* unsused)
{
    struct fork_thread_arguments *fa;
    struct trapframe tmp;

    (void) unsused;
 
    fa = (struct fork_thread_arguments*)args;

    curthread->t_proc = fa->child_proc;
    curthread->t_vmspace = fa->child_vmspace;
	as_activate(fa->child_vmspace);  
    tmp = *fa->child_trapframe; 

    kfree(fa->child_trapframe);
    kfree(fa);

    md_forkentry(&tmp);
}

int sys_fork(struct trapframe* tf, pid_t *retval)
{
    struct fork_thread_arguments *args;
    int res;
    pid_t child_pid;

	args = kmalloc(sizeof(struct fork_thread_arguments));
    if (!args) {
        kprintf("fork: error: fork_thread_arguments");
        return ENOMEM;
    }

    // Let's create new process
    res = proc_create(&args->child_proc);
    if (res) {
        kprintf("fork::proc_create failed\n");
        return res;
    }
    else {
        child_pid = args->child_proc->pid;
        args->child_proc->parent = curthread->t_proc;
    }

    // let's copy trap frame
    args->child_trapframe = kmalloc(sizeof(struct trapframe));
    if (args->child_trapframe == NULL) {
        kprintf("fork: error: child_trapframe");
        return ENOMEM;
    }
	memcpy(args->child_trapframe, tf, sizeof(struct trapframe));

    // let's copy vmspace
    res = as_copy(curthread->t_vmspace, &args->child_vmspace);
	if(res) {
        kprintf("fork: error: as_copy");        
        return ENOMEM;
	}

	res = thread_fork(curthread->t_name, args, NULL, fork_child_entry, NULL);
    if (res) {
        return res;
    }

    *retval = child_pid;
    return 0;
}
