#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <syscall.h>
#include <proc.h>
#include <curthread.h>
#include <thread.h>

int sys_getppid(int *retval)
{
    PROC_LOCK(curthread->t_proc);
    *retval = curthread->t_proc->parent->pid;
    PROC_UNLOCK(curthread->t_proc);
    return 0;
}

