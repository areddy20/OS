#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <sys/wait.h>

static int dofork(void) {
    int pid = fork();
    if (pid < 0) {
        warn("fork");
    }
    return pid;
}

static void dowait(int pid) {
    int status;

    if (pid < 0) {
        return;
    }
    if (pid == 0) {
        exit(0);
    }

    if (waitpid(pid, &status, 0) < 0) {
        warn("waitpid");
    }
    else if (status != 0) {
        warnx("Child pid %d exited with status %d", pid, status);
    }
}

static void test(void) {
    int pid0, pid1, pid2;

    printf("Hello World from my fork test!\n\n\n");
    pid0 = dofork();
    if (pid0 > 0) {
        printf("This is the Parent PID: %d, This is the Child PID: %d\n", getpid(), pid0);
    }

    if (pid0 == 0 || pid0 > 0) {
        pid1 = dofork();
        if (pid1 > 0) {
            printf("Parent PID: %d, Child PID: %d\n", getpid(), pid1);
        }
    }

    if (pid1 == 0 || pid1 > 0) {
        pid2 = dofork();
        if (pid2 > 0) {
            printf("Parent PID: %d, Child PID: %d\n", getpid(), pid2);
        }
    }

    if (pid1 > 0) {
        dowait(pid2);
    }
    if (pid0 > 0) {
        dowait(pid1);
    }
    dowait(pid0);
}

int main() {
    printf("Starting PID fork test.\n");
    test();
    printf("PID fork test complete.\n");
    return 0;
}

