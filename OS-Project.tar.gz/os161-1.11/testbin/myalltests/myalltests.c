#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <err.h>


// Creating a delay using loop calculation
// To prevent compiler optimization, do some random calculation and print it.
void loop() {
	int i;
	int out = 0;
	int v = getpid();
	int sum = 0;

	for (i = 0; i < 10000000; i++) {
		sum += (i ^ v);
	}
	printf("Awake now (ignore) = %d\n", sum);
}


void child_process() {
	loop();
	printf("Child process with pid = %d\n", getpid());
	printf("Child process parent = %d\n", getppid());
	loop();
	printf("Launching testbin/add using execv with these args = add 1 2\n");
	char *args[4];
	args[0] = "add";
	args[1] = "1";
	args[2] = "2";
	args[3] = NULL;
	execv("testbin/add", args);
}

int
main(int argc, char *argv[])
{
	int child;

	printf("Hello World from all of my tests!");
	printf("My Test\n");
	printf("my pid = %d\n", getpid());
	printf("my ppid = %d\n", getppid());

	printf("Forking child\n");
	child = fork();
	if (child == 0) {
		child_process();
	}
	else {
		int return_code;
		printf("In parent, a child process was launched with this pid = %d\n", child);
		printf("Waiting for the child to terminate using waitpid\n");
		waitpid(child, &return_code, 0);
		printf("This is the return code that the parent received %d\n", return_code);
	}

	exit(0);
}


