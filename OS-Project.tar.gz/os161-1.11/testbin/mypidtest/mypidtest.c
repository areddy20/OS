#include <unistd.h>
#include <stdio.h>

int main() {
   pid_t mypid = getpid();
   pid_t parentpid = getppid();

  printf("Hello World from mypidtest!\n");
  printf("My PID: %d\n", mypid);
  printf("My Parent PID: %d\n", parentpid);

  return 0;
}
